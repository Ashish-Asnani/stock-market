import React, { Component } from "react";
import "./mainFile.css";
import Axios from "axios";
class MainScreen extends Component {
  state = {
    searchParam: null,
    searchList: [],
    dataForSearchParam: [],
    apiResponse: [],
   
  };

  componentDidMount() {
 
    this.setState({
      searchParam:this.props.location.state.valueObtained
    },() => {
      Axios.get(
        "https://www.quandl.com/api/v3/datasets/WIKI/" +
          this.state.searchParam +
          ".json?api_key=WizJsEsBGQgx38WDV9Cm"
      ).then(res => {
        let dataObtained = res.data.dataset;
        console.log(dataObtained);
        let dataForTABLE = res.data.dataset.data.splice(0, 10);
        this.setState({
          dataForSearchParam: dataObtained,
          searchList: dataForTABLE
        });
        let data = this.state.dataForSearchParam.data;
        let tableComponent = data.map(data => {
          return (
            <tr>
              <td>ss</td>
              <td>ss</td>
              <td>ss</td>
            </tr>
          );
        });
      });
      Axios.get(
        "https://api.iextrading.com/1.0/stock/"+this.state.searchParam+"/batch?types=quote,news,article,logo,chart&range=1m&last=10"
      ).then(res => {
        console.log(res);
        let dataObtained = res.data;
        console.log(this.state);
        this.setState({
          apiResponse: dataObtained
        });
        console.log(this.state);
      });
      Axios.get(
        "https://api.iextrading.com/1.0/stock/market/previous"
      ).then(res => {
        console.log(res);
        let dataObtained = res.data;
        let list=[];
  Object.keys(dataObtained).map(li=>{
  list.push(li)
  })
        console.log(list)
        console.log(this.state);
      });
    })
    // axios.get('https://www.quandl.com/api/v3/datasets/WIKI/'+this.state.searchParam+'.json?column_index=4&start_date=2018-01-01&end_date=2019-03-31&collapse=monthly&transform=rdiff&api_key=WizJsEsBGQgx38WDV9Cm')
    
  }
  

  

  render() {
    const styles = {
      green: {
        color: '#00ff00'
      },
      red: {
        color: '#ff0000'
      }
    }
    
    
    return (
      <div>

        <div className="row">
          <div className="col s12 m6">
            <div className="card white darken-6">
              <div className="card-content black-text">
                <img
                  className="p-2"
                  src={
                    this.state.apiResponse.logo &&
                    this.state.apiResponse.logo.url
                  }
                  alt="blank"
                />
                <span className="card-title" />
                <h4>{this.state.apiResponse.quote&&this.state.apiResponse.quote.companyName}</h4>
              
                <h6>Symbol: {this.state.apiResponse.quote&&this.state.apiResponse.quote.symbol}</h6>
              </div>
              <div className="collection">
                <a href="#!" className="collection-item">
                  Close:<span className="badge" />
                  {this.state.apiResponse.quote &&
                    this.state.apiResponse.quote.close}
                </a>
                <a href="#!" className="collection-item">
                  Week 52 High:<span className="new badge" />
                  {this.state.apiResponse.quote &&
                    this.state.apiResponse.quote.week52High}
                </a>
                <a href="#!" className="collection-item">
                  Week 52 Low:<span className="new badge" />
                  {this.state.apiResponse.quote &&
                    this.state.apiResponse.quote.week52Low}
                </a>
                <a href="#!" className="collection-item">
                  Exchange:<span className="badge" />
                  {this.state.apiResponse.quote &&
                    this.state.apiResponse.quote.primaryExchange}
                </a>
              </div>
            </div>

            {this.state.apiResponse.news&&this.state.apiResponse.news.map(news=>{
              return(
                <div className="card white darken-6">
              <div className="card-content black-text">
                
                <span className="card-title" />
                <h4>{news.headline}</h4>
              </div>
              <div className="collection">
                <span>{news.summary}</span>
              </div>
            </div>
              )
            })
          }
            

            <div className=" white darken-6">
              <div className="content black-text">
                <span className="title" />
                <h4>{this.state.dataForSearchParam.name}</h4>
              </div>
              <div className="data">
                <span>{this.state.dataForSearchParam.description}</span>
              </div>
            </div>
            
          </div>
          
          <div className="col s12 m6">
            <table>
              <thead>
                <tr>
                  <th>DATE</th>
                  <th>OPEN</th>
                  <th>HIGH</th>
                  <th>CLOSE</th>
                </tr>
              </thead>

              <tbody>
                {this.state.apiResponse.chart != null
                  ? this.state.apiResponse.chart.map(data => (
                      <tr>
                        <td>{data.date}</td>
                        <td>{data.open}</td>
                        <td>{data.high}</td>
                        <td style={data.open>data.close?styles.green : styles.red}>{data.close}
                        {data.open<data.close?<i class="material-icons" style={styles.red}>arrow_downward</i>:<i class="material-icons" style={styles.green}>arrow_upward</i>}
                        
                        </td>
                      </tr>
                    ))
                  : null}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }
}

export default MainScreen;
